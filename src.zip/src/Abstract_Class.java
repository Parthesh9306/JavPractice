
public abstract class Abstract_Class {


		
		public void concrete_method()
		{
			System.out.println("Printing Concrete Method");
		}
		
		public void concrete_method_2()
		{
			System.out.println("Printing Concrete Method 2");
		}
		
		public abstract void non_concrete_method();
		
		public abstract void non_concrete_method_2();
		
	

}
