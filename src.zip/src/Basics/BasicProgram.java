package Basics;

import methodOverridingRules.Parent;

public class BasicProgram extends Parent{

	
	public static void main(String args[])
	{
		
		
		int i =5;
		firstmethod();
		
		BasicProgram bpr = new BasicProgram();
		 bpr.secondmethod();
		 bpr.multiplication();
		 bpr.substract(); // it can't be created as it is created with default
		
	}
	
	public static void firstmethod()
	{
		System.out.println("First Method");
	}
	
	public void secondmethod()
	{
		System.out.println("Second Method");
	}
	
}
