package Basics;

public class ClassConcept {

	int modelyear;
	String brand;
	public static void main(String args[])
	{
		ClassConcept TATA = new ClassConcept();
		TATA.modelyear = 2018;
		TATA.brand = "TATA Motors";
		
		ClassConcept Hero = new ClassConcept();
		Hero.modelyear = 2017;
		Hero.brand = "Hero";

		System.out.println("Barand is :" +TATA.brand + "\n" + "Model is :" +TATA.modelyear);
		System.out.println("Barand is :" +Hero.brand + "\n" + "Model is :" +Hero.modelyear);
	}
	
}
