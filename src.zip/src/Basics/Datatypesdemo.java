package Basics;

public class Datatypesdemo {
	
	public static void main(String[] args)
	{
		int number = 1236777889;
		long num = 1236777889075656565L;
		float num2 = 123.0567f;
		double num3 = 123.00d;
		char name='a';
		boolean flag=true;
		
		System.out.println(number);
		System.out.println(num);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(name);
		System.out.println(flag);
	}

}
