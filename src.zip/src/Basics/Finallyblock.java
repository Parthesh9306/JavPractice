package Basics;

public class Finallyblock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try{
			System.out.println("parthesh");
			//System.exit(0); ==> if enabled then finally block will not be executed
		}
		finally{
			System.out.println("joshi");
		}
		
	}

}
