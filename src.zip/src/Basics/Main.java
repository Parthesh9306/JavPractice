package Basics;

public class Main {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Main Class with Main method");
		
		Main m= new Main();
		m.main(args);

	}
	
	public void hello()
	{
		System.out.println("Hello");
	}

}
