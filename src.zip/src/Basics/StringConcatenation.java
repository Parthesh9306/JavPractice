package Basics;

public class StringConcatenation {

	public static void main(String args[])
	{
		
		int a=100;
		int b=200;
		
		String x ="hello";
		String y ="world";
		
		System.out.println(a+b+x+y); // left to right concatenation (output = 300helloworld)
		
		System.out.println(x+y+a+b); // left to right concatenation (output = helloworld100200)
		
		System.out.println(x+y+(a+b)); // helloworld300
		
		System.out.println(x+y+a+x+b+y);//helloworld100hello200world
		
		
		String temp = "OFAC6236066";
		
		String temp1= temp.substring(0,9);
		
		System.out.println(temp1);
	}
	
}
