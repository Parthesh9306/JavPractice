
public class Child {

	public static void main(String[] args) {
		
		Parent p = new Parent();
		System.out.println(p.i);
		p.display();
	}
}
