import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.HashMap;

public class Duplicate_Charcaters_From_String {

	public static void main(String[] args) {
		
		String str = "partheshjoship";
		
		String str1= str.toLowerCase();
		
		Set<Character> s1 = new HashSet<>();
		//HashMap<Character, Integer> hmap = new HashMap<Character, Integer>();
		
		
		for(int i=0;i<str1.length();i++)
		{
			for(int j=i+1;j<str1.length();j++)
			{
				if(str1.charAt(i)==str1.charAt(j))
				{
					s1.add(str1.charAt(i));
					//hmap.put(str1.charAt(i),i);
				}
			}
		}

		System.out.println(s1);
		//Map.Entry<Character, Integer> me = (Entry<Character, Integer>) hmap.entrySet();
		
		/*for(Map.Entry me1 : hmap.entrySet())
		{
			System.out.println(me1.getKey());
		}*/
	}

}
