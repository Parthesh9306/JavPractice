class Student
{

	private int studentrollnum= 0;
	
	public void setstudentrollnumber(int rollnumber)
	{
		this.studentrollnum = rollnumber;
		
	}
	
	public int getstdentrollnumber()
	{
		System.out.println(studentrollnum);
		
		return studentrollnum;
	}

}

public class Encapsulation 
{
	
	public static void main(String[] args)
	{
		
		Student s  = new Student();
		
		s.setstudentrollnumber(101);
		s.getstdentrollnumber();

	}

}
