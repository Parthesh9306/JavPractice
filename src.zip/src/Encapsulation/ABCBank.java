package Encapsulation;

public class ABCBank extends Loan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ABCBank bank = new ABCBank();
		
		bank.interestrate = 10;
		
		bank.printInterestRate();
		
	}

}
