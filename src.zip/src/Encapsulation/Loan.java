package Encapsulation;

public class Loan {

	public int interestrate ;
	public String tenure;
	
	public void printInterestRate()
	{
		System.out.println("Home Loan Interest is : " +interestrate);
	}
	
	public void printLoanTenure()
	{
		System.out.println("Home Loan Tenure is : " +tenure);
	}
}
