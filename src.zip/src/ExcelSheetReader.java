import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.DataFormatter;

import org.apache.poi.xslf.usermodel.XSLFSheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelSheetReader {
	
	public static XSSFCell sheetdata;
	
	public static void main(String[] args) throws Exception 
	{
		
		FileInputStream fis = new FileInputStream("D:\\ExcelSheet.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0);
		int lastrownum = sheet.getLastRowNum();
		
		
		for(int row=1;row<=lastrownum;row++)
		{
		    sheetdata = sheet.getRow(row).getCell(0);
		    
		    DataFormatter df = new DataFormatter();
			df.formatCellValue(sheetdata);
		    
		    System.out.println(sheetdata);
		}
		
		
		

	}

}
