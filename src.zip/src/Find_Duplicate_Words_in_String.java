
public class Find_Duplicate_Words_in_String {

	public static void main(String[] args) {
		
		String str= "Abhinav Nimkar Abhinav";
		String[] words = str.split(" ");
		int count=0;
		
		for(int i=0;i<=words.length;i++)
		{
			for(int j=i+1;j<words.length;j++)
			{
				if((words[i].equals(words[j])))
				{
					System.out.println("Duplicate are:"+words[j]);
					//count++;
					
				}				
				
					
			}
			
		}
	}

}
