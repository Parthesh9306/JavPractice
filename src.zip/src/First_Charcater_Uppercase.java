
public class First_Charcater_Uppercase {

	public static void main(String[] args) {

		int[] num = {1,2,3,4,5,6};
		
		int largest = num[0];
		int secondlargest = num[0];
		
		for(int i=0;i<num.length;i++)
		{
			
			if(num[i]>largest)
			{
				secondlargest = largest;
				largest = num[i];
			}
			
			else if(num[i]>secondlargest)
			{
				secondlargest = num[i];
			}
		}
		
		//System.out.println("Largest number is:"+largest);
		System.out.println("Second largest number is:"+secondlargest);
		
	}

}