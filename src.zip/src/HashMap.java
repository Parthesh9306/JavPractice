import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class HashMap {

	public static void main(String[] args) {
		
		
		java.util.HashMap<Integer,String> hmap = new java.util.HashMap<Integer,String>();
		
		hmap.put(1, "Ram");
		hmap.put(2, "Shyam");
		hmap.put(3, "Sita");
		hmap.put(4, "Gita");
		
		//for loop
		
		for(Map.Entry me:hmap.entrySet())
		{
			System.out.println("Key is:"+me.getKey() + "Value is:"+me.getValue());
		}
		
		//while loop and Iterator
		
		Iterator iterator = hmap.entrySet().iterator();
		
		while(iterator.hasNext())
		{
			Map.Entry me2 = (Entry) iterator.next();
		
			System.out.println("Key is:"+me2.getKey() + "Value is:"+me2.getValue());
		}
		
		
		
		
}
	
}
		
		