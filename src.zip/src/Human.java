// Example of Static Binding
// Static Binding is a Example of Compile Time PolyMorphism
// Because Which Method is to be called is Chosen During Compile Time
// Compile Time polyMorphism means Method Overloading
// Output of the programs will Be Human Walk and Human Walk 
// Because Here methods are declared as a Static and hence they cannot be Overridden

public class Human {

	public static void walk()
	   {
	       System.out.println("Human walks");
	   }
	
	public static void main(String args[]) {
		
	       /* Reference is of Human type and object is
	        * Boy type
	        */
	       Human obj = new Boy();
	       /* Reference is of HUman type and object is
	        * of Human type.
	        */
	       Human obj2 = new Human();
	       obj.walk();
	       obj2.walk();
	   }
	}
	class Boy extends Human{
	  
		public static void walk()
		{
	       System.out.println("Boy walks");
	   }
	  
	   
}
