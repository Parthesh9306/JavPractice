import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBC_Connectivity {

	public static void main(String[] args) {
		Connection con = null;
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			try {
				
				con=DriverManager.getConnection("jdbc:Oracle:thin:NED46_SCD09/payplus1@//linuxserver6.fundtech.isr:1521/NED");
			} catch (SQLException e) {
				// TODO: handle exception
			}
			
			//linuxserver6.fundtech.isr:1521/NED
			//@localhost:1521:xe
			//step3 create the statement object  
			java.sql.Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select * from BANKS");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
			  
			//step5 close the connection object  
			con.close();  
			  
			}
		
		    catch(Exception e)
		     
		     { 
		    	System.out.println(e);
		    	
		     }  
			  
			}  
			

	}


