package OOPS;

public class InheritancewithMethodOverriding extends SampleClassOne {

	static int k=9;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		InheritancewithMethodOverriding iwm = new InheritancewithMethodOverriding();
		
		iwm.Method1();
		
	int i=7;
	int j=9;

	}
	
	public void Method1() // method is overridden with parent class method1
	{
		System.out.println("Method 1 from child class");
		super.Method1(); // executes method 1 from parent class
		k=k+10;
		System.out.println(k);
	}

}
