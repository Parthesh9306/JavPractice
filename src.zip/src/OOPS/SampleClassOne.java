package OOPS;

public class SampleClassOne {

	SampleClassOne()
	{
		System.out.println("Constructor from parent class");
	}
	
	public void Method1()
	{
		System.out.println("Sample class one method one");
	}
	
	public void Method2()
	{
		System.out.println("Sample class one method two");
	}
	
}
