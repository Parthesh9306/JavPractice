package OOPS;

public class SampleClassThree extends SampleClasstwo{

	public static void main(String args[])
	{
		
		SampleClassThree samthree = new SampleClassThree();
		samthree.SampleClassThreeMethodone();
		
		samthree.sampleclasstwomethodone(); // method from extended class
		
		samthree.Method1();// method from parent class which is extended by SampleClassTwo
	}
	
	public void SampleClassThreeMethodone()
	{
		System.out.println("First Method from class three");
	}
	
}
