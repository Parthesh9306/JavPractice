package OOPS;

import Basics.BasicProgram;

public class SampleClasstwo extends SampleClassOne{

	public static void main(String args[])
	{
	 SampleClasstwo samtwo = new SampleClasstwo(); // it will also execute constructor of parent class
	samtwo.sampleclasstwomethodone(); // method of same class
	 samtwo.sampleclasstwomethodtwo(); // method of same class
	 
	 samtwo.Method1(); // method of extended class
	 
	 BasicProgram.firstmethod();// class imported from diffeent package
	 
	 SampleClassOne samone = new SampleClassOne(); // object of extended class
	 
	 samone.Method2(); // extended class method execution
	}
	
	public void sampleclasstwomethodone()
	{
		System.out.println("Sample Class Two Method one");
	}
	
	public void sampleclasstwomethodtwo()
	{
		System.out.println("Sample Class Two Method two");
		//sampleclasstwomethodtwo();
	}
}
