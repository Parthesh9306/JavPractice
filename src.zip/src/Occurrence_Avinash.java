
public class Occurrence_Avinash {
	public static void main(String[] args) {
		String str = "abhinav";
		int count = 1;
		for (int i = 0; i < str.length(); i++) 
		{
			for (int j = i + 1; j < str.length(); j++) 
			{
				if (str.charAt(i)==str.charAt(j)) 
				{
					count++;
				}
			}
			
			System.out.println("Character \'"+str.charAt(i)+"\' occures "+count+" times");
			count=1;
			
		}
		
		
	}

}
