
public class Occurrence_another_type {

	public static void main(String[] args) {
		
		String str= "abhinav";
		//String str1 = str.toLowerCase();
		int count=0;
		
		for(char i='a';i<='z';i++)
		{
			for(int j=0;j<str.length();j++)
			{
				if(str.charAt(j)==i)
				{
					count++;
				}
			}
			
			
			if(count!=0)
			{
				System.out.println(i+"="+count);
				count=0;
			}
			
		}
		
	}

}
