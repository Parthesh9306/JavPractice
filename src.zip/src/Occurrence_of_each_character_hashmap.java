import java.util.HashMap;
import java.util.Map;

public class Occurrence_of_each_character_hashmap {

	public static void main(String[] args) {
		
		String str = "abhinav pune abhinav nagpur";
		
		//Converting String to chararray
		char[] chararray = str.toCharArray();
		
		//Creating hashmap containing char as a key and integer as a value 
		HashMap<Character,Integer> hmap = new HashMap<Character,Integer>();
		
		//checking each character of chararray
		for(char c:chararray)
		{
			if(hmap.containsKey(c))
			{
				//If char is present in hmap, incrementing it's count by 1
				hmap.put(c, hmap.get(c)+1);
			}
			
			else
			{
				//If char is not present in hmap,
                //putting this char to hmap with 1 as it's value
				hmap.put(c, 1);
			}
		}
		
		System.out.println(hmap);

	}

}
