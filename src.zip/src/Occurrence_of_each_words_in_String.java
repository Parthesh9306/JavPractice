
public class Occurrence_of_each_words_in_String {

	public static void main(String[] args) {
		
		int count=0;
		String str= "Abhinav Pune Abhinav Nagpur";
		String matching = "Abhinav";
		
		String[] newstr = str.split(" ");
		
		/*for(int i=0;i<newstr.length;i++)
		System.out.println(newstr[i]);*/
		System.out.println("newstr.length:-"+newstr.length);
		for(int i=0;i<newstr.length;i++)
		{
			for(int j=i;j<=i;j++){
				if(newstr[i].equals(newstr[j]))
				{
					count = count+1;
				}
			
			}
			System.out.println(newstr[i]+" := "+count);
				count = 0;
		}
		
		//System.out.println("Abhinav = "+count);
		//count=0;

	}

}
