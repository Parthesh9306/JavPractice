import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class Occurrence_of_words_in_string_hashmap {
	static int count =0;
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

		String str = "Abhinav Pune Abhinav Nagpur";
		String[] newstr= str.split(" ");
		
		Map<String,Integer> hmap = new  HashMap<String,Integer>();
		
		for(int i=0;i<newstr.length;i++)
		{
			for(int j=i;j<=i;j++)
			{
				if (newstr[i].equals(newstr[j]))
				{
					
					if(hmap.containsKey(newstr[i]))
					{
						count= hmap.get(newstr[i]);
					}
					count = count+1;
					
					hmap.put(newstr[i], count);
				}
				
				
			}
			
			count=0;
			
			
		}
		
		
		for (Entry<String, Integer> entry : hmap.entrySet()) 
            System.out.println("Key = " + entry.getKey() +
                             ", Value = " + entry.getValue());
		
		

	}

}
