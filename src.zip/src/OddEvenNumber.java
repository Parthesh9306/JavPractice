import java.util.Scanner;

public class OddEvenNumber {

	public static void main(String[] args) {
	
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a Number:");
		
		int num = scan.nextInt();
		scan.close();
		
		if(num % 2 == 0)
		{
			System.out.println("Number is even number");
		}
		
		else
		{
			System.out.println("Number is odd");
		}

	}

}
