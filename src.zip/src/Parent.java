
public class Parent {

	int i=10;
	void display()
	{
		System.out.println("Parent Class");
	}
}
