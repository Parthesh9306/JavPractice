import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Practice {

	
	public static String JDBC_Connectivity(String conection_url,String Username,String Password,String QueryToExecute,String Col_Name, String Col_Name_1) {
		
		// Load the Oracle Driver
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		
		catch (ClassNotFoundException e) 
		{
			
			e.printStackTrace();
		}
		
		//Create Driver Connection
		
		try 
		{
			Connection con = DriverManager.getConnection(conection_url, Username, Password);
		
			Statement stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery(QueryToExecute);
		
			while(rs.next()) 
			{
				System.out.println("MID: "+rs.getString(Col_Name) + " "+ "Message Type: "+rs.getString(Col_Name_1));
			}
			
			
			if(rs!=null) 
			{
				rs.close();
			}
			
			if(stmt!=null) 
			{
				stmt.close();
			}
			
			if(con!=null) 
			{
				con.close();
			}
		} 
		
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		return Col_Name_1;
		
		
		
		
		
		
		
	}
	
	

}
