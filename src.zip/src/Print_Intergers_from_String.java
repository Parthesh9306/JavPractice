import java.util.Arrays;

public class Print_Intergers_from_String {

	public static void main(String[] args) {
		
		String str = "Test325 is6 good123";
		
		int total=0;
		
		String str1 = str.replaceAll("[a-zA-Z]", "");
		
		System.out.println(str1);
		
	//	int num = Integer.parseInt(str1);

		for (int i = 0; i<str1.length();i++) 
		{
			
			total = total + Integer.parseInt(str1);
			
		}
		
		System.out.println("Sum is:"+total);
	}

}
