
public class Print_only_first_occurrence_of_character_in_string {

	public static void main(String[] args) {
		

		String str = "alive is awesome";
		
		String expectedstring = " ";
		
		
		for(int i=0;i<str.length();i++)
		{
			char chararray = str.charAt(i);
			System.out.println(chararray);
			if(chararray!=' ')
			{
				expectedstring = expectedstring +chararray;
			}
			
			str = str.replace(chararray, ' ');
		}
		
		
	//System.out.println(expectedstring);	
	}
	
	
	}


