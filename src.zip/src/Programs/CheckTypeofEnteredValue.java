package Programs;

import java.io.InputStream;
import java.util.Scanner;

public class CheckTypeofEnteredValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Please enter value : ");
    
		Scanner scan = new Scanner(System.in);
		String str = scan.next();
		
		/*char ch[] = str.toCharArray();
		
		System.out.println(str);
		
		for(int i=0; i<str.length();i++)
		{
			if(Character.isDigit(ch[i]) == true)
			{
				System.out.println("Integer");
			}
			else
			{
				System.out.println("String");
			}
		}*/
		
		try
		{
		Integer.parseInt(str);
		System.out.println("Entered value is Integer");
		}
		catch(Exception e)
		{
			System.out.println("Entered value is String");
		}
	}
		

	

}
