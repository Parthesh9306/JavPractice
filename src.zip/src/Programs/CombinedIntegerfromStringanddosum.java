package Programs;

public class CombinedIntegerfromStringanddosum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1 = "Abhinav12 Parthesh12 Ajeet12 Alok12";
		String s2="";
		int total = 0;
		
		
		for(int i=0;i<s1.length();i++)
		{
			if(s1.charAt(i)==' ')
			{
				s2 = String.valueOf(s1.charAt(i-2))+String.valueOf(s1.charAt(i-1));
				total = total + Integer.parseInt(s2);
			}
		}
		s2 = String.valueOf(s1.charAt(s1.length()-2))+String.valueOf(s1.charAt(s1.length()-1));
		total = total + Integer.parseInt(s2);
		System.out.println(total);
		
		
		
	}

}
