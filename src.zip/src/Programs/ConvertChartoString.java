package Programs;

public class ConvertChartoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char ch[] = {'d','r','q','g','y'};
		
		String str = String.valueOf(ch);
		System.out.println(str);
		
	}

}
