package Programs;

public class FibonacciSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int count=6;
		int num1=0;
		int num2=1;
		int sumofprevtwo=0;
		
		for(int i=0;i<=count;i++)
		{
			System.out.print(num1+" ");
			
			sumofprevtwo = num1+num2;
			num1=num2;
			num2=sumofprevtwo;

		}
		
	}

}
