package Programs;

public class FindDuplicatefromstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        String str = "Abhinav nimkar";
		
		String str1= str.toLowerCase();
		
		for (int i = 0; i < str1.length(); i++) {
			
			for(int j=i+1;j<str1.length();j++)
			{
				if(str1.charAt(i)==str1.charAt(j))
				{
					System.out.println("Duplicates are:"+str1.charAt(j));
				}
			}
		}

	}

}

