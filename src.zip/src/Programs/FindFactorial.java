package Programs;

import java.util.Scanner;

public class FindFactorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Enter number to find factorial : ");
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		int ans = 1;
		for(int i=num;i>0;i--)
		{
			ans = ans*i;
		}
		
		System.out.println("Factorial of "+num+" is : "+ans);
	}

}
