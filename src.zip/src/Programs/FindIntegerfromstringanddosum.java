package Programs;

public class FindIntegerfromstringanddosum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int total =0;
		String str = "p12rthe45sd#477";
		char[] ch = str.toCharArray();
		for(int i=0;i<str.length();i++)
		{
			try{
			//Integer.parseInt(String.valueOf(ch[i]));
			total = total + Integer.parseInt(String.valueOf(ch[i]));
			}
			catch(Exception e)
			{
				
			}
		}
		System.out.println(total);
	}

}
