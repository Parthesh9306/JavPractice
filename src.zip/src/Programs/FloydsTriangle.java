package Programs;

public class FloydsTriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num=1;
		int rows=5;
		int j,counter;
		for(counter=1 ;counter<=rows;counter++)
		{
			for(j=1;j<=counter;j++)
			{ 
				
				System.out.print(num+" ");
				num++;
			}
			System.out.println("");
		}
		
	}

}
