package Programs;

public class Patterns {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num = 0;
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=5;j++)
			{
				num++;
				System.out.print(num);
			}
			System.out.println("");
		}
		
	}

}
