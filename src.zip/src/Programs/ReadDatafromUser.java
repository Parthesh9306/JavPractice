package Programs;

import java.util.Scanner;

public class ReadDatafromUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Please enter some value : ");
		
		Scanner scan = new Scanner(System.in);
		int i = scan.nextInt();
		
		System.out.println("You have entered : " +i);
		
	}

}
