package Programs;

import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Enter String to reverse : ");
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		//String str= "parthesh 9306 joshi @#  454";
		String reverse="";
		//char ch[] = str.toCharArray();
		for(int i=str.length()-1;i>=0;i--)
		{
			reverse = reverse+(str.charAt(i));
		}
		System.out.println("Reverse string is :"+reverse);
	}

}
