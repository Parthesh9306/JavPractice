package Programs;

import java.util.Arrays;

public class SortAnArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int array[] = {1,56,34,67,23};
		
		Arrays.sort(array);
		for (int i=0; i<array.length;i++)
		{
			System.out.println(array[i]);
		}
	}

}
