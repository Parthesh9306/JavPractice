package Programs;

import java.util.Arrays;
import java.util.Collections;

public class SortanArrayinReverseOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//int array[] = {1,56,34,67,23};
		
		Integer[] intArray = new Integer[] {
		        new Integer(15),
		        new Integer(9),
		        new Integer(16),
		        new Integer(2),
		        new Integer(30)
		    };
		
		Arrays.sort(intArray,Collections.reverseOrder());
		
		System.out.println("intArrayin reverse order is : ");
		for (int i=0; i<intArray.length;i++)
		{
			
			System.out.println(intArray[i]);
		}
	
	}

}
