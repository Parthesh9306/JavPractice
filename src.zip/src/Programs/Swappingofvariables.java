package Programs;

public class Swappingofvariables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=55;
		int b=15;
		
		int temp;
		
//		temp=a;
//		a=b;
//		b=temp;
		
		a=a+b;
		b=a-b;
		a=a-b;
		
		
		System.out.println(a);
		System.out.println(b);
		
		
	}

}
