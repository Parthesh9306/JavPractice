package Programs;

import java.util.Scanner;

public class count_string_and_integer_from_entered_values {

	int intcount,strcount;
	
	public static void main(String[] args) {
		
		int intcount = 0;
		int strcount = 0;
	
		System.out.println("Please enter value : ");
	    
		Scanner scan = new Scanner(System.in);
		String str = scan.next();
		
		char ch[] = str.toCharArray();
		
		System.out.println(str);
		
		for(int i=0; i<str.length();i++)
		{
			if(Character.isDigit(ch[i]) == true)
			{
				intcount++;
			}
			else
			{
				strcount++;
			}
		}
		
		System.out.println("Number of Integer values are : " +intcount);
		System.out.println("Number of String values are : " +strcount);
		
		
	}

}
