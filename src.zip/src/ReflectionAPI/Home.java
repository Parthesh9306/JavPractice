package ReflectionAPI;

import java.lang.reflect.Method;

public class Home {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test t = new Test();
		System.out.println(t.getClass().getSimpleName());
		
		Class clazz = t.getClass();
		System.out.println(clazz.getSimpleName());
	
		Method[] arrayofmethods = clazz.getDeclaredMethods();
		System.out.println("Total methods are : " +arrayofmethods.length);
		
		for (Method m : arrayofmethods)
		{
			System.out.println(m.getName()+" ======Return Type is ==== "+m.getReturnType());
		}
	}

}
