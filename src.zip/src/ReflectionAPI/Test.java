package ReflectionAPI;

public class Test {

	
	public int add()
	{
		return 0;
		
	}
	
	public double sub()
	{
		return 10.55;
	}
	
	private void print() // we can also get information of private methods using reflection 
	{
		
	}
}
