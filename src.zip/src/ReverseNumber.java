import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) 
	
	{
	
		int num=0,input =0;
		int reversenum=0;
		
		System.out.println("Input your number and press enter: ");
		
		Scanner in = new Scanner(System.in);
		input = in.nextInt(); 
		num= input;
		
		while(num!=0)
		{
			
			reversenum = reversenum*10;
			reversenum = reversenum + num%10;
			num=num/10;
			
		}
		
		System.out.println("Reverse number is :"+reversenum);
		
		if(reversenum == input)
		{
			System.out.println("The given number is palindrome");
			
		}
		
		else
		{
			System.out.println("The given number is not palindrome");
		}
		
			
		

	}

}
