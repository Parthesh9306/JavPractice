import java.util.Arrays;

public class Reverse_Each_Words {

	public static void main(String[] args) {
		
		String str = "my name is abhinav";
		String reversestring= "";
		
		String[] words = str.split(" ");
		
		
		for(int i=0;i<words.length;i++)
		{
			String word = words[i];
			
			String reverseword = " ";
			
			for(int j=word.length()-1;j>=0;j--)
			
			{
				reverseword = reverseword + word.charAt(j);
			}
			
			reversestring = reversestring + reverseword;		
			
		}
		
		System.out.println(reversestring);

	}

}
