
public class Reverse_Number {

	public static void main(String[] args) {
		
		int num =105;
		int reversenumber = 0;
		
		while(num!=0)
		{
			reversenumber = reversenumber*10;
			reversenumber = reversenumber + num%10;
			num = num/10;
			
			
		}

		System.out.println("Reverse of given number is :"+reversenumber);
	}

}
