import java.util.Scanner;

public class Reverse_String {

	public static void main(String[] args) 
	
	{
	 
		String original = "";
		String reverse = "";
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter a String to reverse: ");
		
		original = in.nextLine();
		
		for(int i=original.length()-1;i>=0;i--)
		{
			reverse = reverse +original.charAt(i);
		}
		
		System.out.println("Reverse of Entered is:"+reverse);
		
		if(reverse.equals(original))
		{
			System.out.println("The String is palindrome");
		}
		
		else
		{
			System.out.println("The String is not palindrome");
		}
		
		

	}

}
