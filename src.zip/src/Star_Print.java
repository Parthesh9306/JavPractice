import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Star_Print
{


	
	public static void main(String[] args) {
	
		// for printing rows
		
		for(int i=1;i<=5;i++)
		{
			//for printing spaces 
			
			for(int j=i;j<=5;j++)
			{
				System.out.print(" ");
			}
			
			//for printing stars
			
			for (int k=1;k<=i;k++)
			{
				System.out.print("* ");
			}
			
			System.out.println();
		}
		
		
		
		}
		
	}






