
public class Star_Print_three {

	public static void main(String[] args) {
		
		// for printing stars
		for(int i=1;i<=5;i++)
		{
			//for printing spaces
			
			for(int j=i;j<=5;j++)
			{
				System.out.print(" ");
			}
			
			// for printing stars
			
			for(int k=1;k<=(2*i-1);k++)
			{
				System.out.print("*");
			}
			
			System.out.println();
			
		}

			
	}

}
