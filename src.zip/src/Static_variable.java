
public class Static_variable {

	static int number;
	int number1;
	
	public static void main(String[] args) {
		
		Static_variable.number=1;
	
		 
		

	}

}
