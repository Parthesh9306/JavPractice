

public class String_Anagram_Check {

	public static void main(String[] args) {
		
			String str = "abhinav pune abhinav nagpur";
			
			
			
		
			
			
			
				
			
			
	}

}
