
public class Sum_of_all_digits {

	public static void main(String[] args) {
		
		int number = 12345;
		
		int sum=0;
		
		while(number!=0)
		{
			int lastdigit = number%10;
			
			sum = sum + lastdigit;
			
			number = number/10;
		}
		
		System.out.println("Sumof all digits are: " +sum);

	}

}
