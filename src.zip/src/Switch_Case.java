
public class Switch_Case {

	public static void main(String[] args) {
		
		int num=2;
		
		switch (num+1) 
		
		{
		case 1:
			
			System.out.println("Case 1 value is :"+num);
			
		case 2:
			
			System.out.println("Case 2 value is :"+num);
			
		case 3:
			
			System.out.println("Case 3 value is :"+num);

		default:
			
			System.out.println("default value is :"+num);
		}

	}

}
