
public class Uppercase {

	public static void main(String[] args) {
		
		String str = "fundtech india pvt. ltd.";
		
		char[] strnew = str.toCharArray();
		
		System.out.println(strnew);
		
		//uppercase first letter
		
		strnew[0] = Character.toUpperCase(strnew[0]);
		
		// uppercase all letter that follows a white space
		
		for(int i=1;i<strnew.length;i++)
		{
		
			if(Character.isWhitespace(strnew[i-1]))
			{
				strnew[i] = Character.toUpperCase(strnew[i]);
			}
		}
		
		System.out.println(strnew);
		
	}

}
