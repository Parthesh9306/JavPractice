import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class While {

	public static void main(String[] args) {
		String s = "Hello123";
		Pattern p = Pattern.compile("[aieou][123]");
		Matcher m = p.matcher(s);

		while (m.find()) {
			System.out.println(m.group());

		}
	//	System.out.println(s);

	}

}
