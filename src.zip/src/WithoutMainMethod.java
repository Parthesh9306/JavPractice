
public class WithoutMainMethod {

	static // it was allowed till Java6 but after Java 6 it is not allowed
	{
		System.out.println("Without main method");
		
		System.exit(0);
	}
	
}
