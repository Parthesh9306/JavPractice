package collections;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		ArrayList al = new ArrayList(); // array list without generics
		ArrayList<String> al1 = new ArrayList<String>(); // array list with generics
		
		al.add(null);
		al.add("abc");
		al.add(25.69);
		al.add("");
		al.add(34);
		al.add(null);
		al.add('D');
	
		System.out.println(al);
		
		al.remove(null);
		
		System.out.println(al);
		// all methods are same as List interface as ArrayList class is implementing list interface 
	}

}
