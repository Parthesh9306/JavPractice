package collections;

import java.util.ArrayList;
import java.util.HashSet;

public class ArrayListtoSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList alist = new ArrayList();
		alist.add("parthesh");
		alist.add(12);
		alist.add(25);
		alist.add('c');
		alist.add("parthesh");
		alist.add(12);
		
		HashSet hset = new HashSet(alist);
		System.out.println(hset);
	
	}

}
