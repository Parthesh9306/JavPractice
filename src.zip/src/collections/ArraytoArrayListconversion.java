package collections;

import java.util.ArrayList;
import java.util.Arrays;

public class ArraytoArrayListconversion {

	public static void main(String[] args) {

		String[] array = {"abc","def","parthesh"};
		
		ArrayList arrayList = new ArrayList(Arrays.asList(array));
		System.out.println(arrayList);
		System.out.println(arrayList.get(2));

	}

}
