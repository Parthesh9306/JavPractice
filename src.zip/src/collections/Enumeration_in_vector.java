package collections;

import java.util.Enumeration;
import java.util.Vector;

public class Enumeration_in_vector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  i=0;
		Vector v = new Vector();
		Vector<String> v1 = new Vector<>();
		
		for (i=0;i<=5;i++)
		{
			v.addElement(i);
		}
		
		System.out.println(v);
		Enumeration e = v.elements();	
		
		while(e.hasMoreElements())
		{
			//System.out.println(e.nextElement());
			int j = (Integer) e.nextElement();
			System.out.println(j);
		}
		
		
		v1.add("Parthesh");
		v1.add("Abhinav");
		v1.add("Ajeet");
		v1.add("Krishna");
		v1.add("Radhika");
		
		System.out.println(v1);
		
		Enumeration e1=v1.elements();
		
		while(e1.hasMoreElements())
		{
			//System.out.println(e1.nextElement());
			
			String empnames = (String)e1.nextElement();
			
			System.out.println(empnames);
		}
	}
}
