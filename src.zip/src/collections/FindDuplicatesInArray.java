package collections;

public class FindDuplicatesInArray {

	public static void main(String[] args) throws InterruptedException {
		
		/*int a[] = {10,20,10,30,40,40};
		int b[] = new int[6];
		
		for (int i = 0 ; i <=a.length-1 ;i++)
		{
			
			
			for (int j=i+1; j<=a.length -1 ; j++)
			{
			 if(a[i] != a[j])
			  {
				b[i] = a[i];
			  }
			}
		}
		
		for (int i = 0 ; i <=b.length-1 ;i++)
		{
			System.out.println(b[i]);
		}*/
		
		int num[]={4,4,3,2,6,7,4,2,1,2,8,6,7};
        for(int i=0; i<num.length; i++){
            boolean isdistinct = true;
            for(int j=0; j<i; j++){
                if(num[i] == num[j]){
                    isdistinct =false;
                    break;
                }
           }
            if(isdistinct){
                System.out.print(num[i]+" ");
            }
       }
   }
	}
	

