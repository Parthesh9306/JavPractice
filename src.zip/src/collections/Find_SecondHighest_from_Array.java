package collections;

public class Find_SecondHighest_from_Array {

	public static void main(String[] args) {
		
		int[] array = {2,6,1,43,36,40,55,61,74,45,61};
		
		int highest = 0;
		int secondhighest = 0;
		
		for(int i=0;i<array.length;i++)
		{
			if(array[i]>highest)
			{
				secondhighest = highest;
				highest=array[i];
			}
			else if(array[i]>secondhighest)
			{
				secondhighest = array[i];
			}
		}

		System.out.println("secondhighest is : " +secondhighest);
	}

}
