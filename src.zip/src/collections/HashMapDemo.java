package collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		HashMap hmap = new HashMap();
		
		HashMap<String,Integer> hmap1 = new HashMap<String,Integer>();
		
		Map<String,Integer> hmap2 = new HashMap<String,Integer>();
		
		hmap1.put("Parthesh", 26);
		hmap1.put("Abhinav", 28);
		hmap1.put("Ajeet", 30);
		hmap1.put("Radhika", 25);
		
		
		System.out.println(hmap1);
		if(hmap1.containsKey("Abhinav")) // check whether abhinav is present or not
		{
			System.out.println("Age of ABhinav is : " +hmap1.get("Abhinav"));
		}
		
		hmap1.remove("Radhika");
		System.out.println(hmap1);
		
		System.out.println("Size of the hashmap is : " +hmap1.size());
		
		hmap1.clear(); // to flush hashmap
		
		System.out.println(hmap1);
		
		hmap2.put("Krishna", 25);
		hmap2.put("Abhinav", 28);
		hmap2.put("Ajeet", 30);
		hmap2.put("Parthesh", 26);
		
		for(Map.Entry<String, Integer> entry : hmap2.entrySet())
		{
			System.out.println("Key = " +entry.getKey() + ", Value = " +entry.getValue());
		}
	}

}
