package collections;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		HashSet hash = new HashSet();
		
		hash.add(null);
		hash.add("Parthesh");
		hash.add("Abhinav");
		hash.add("");
		hash.add("Ajeet");
		hash.add("Krishna");
		hash.add("Abhinav");// it will not allow duplicate value
		hash.add(null);// it will not allow duplicate value
		
		System.out.println(hash);
		
		//verify that HashSet contains particular object or not
		
		System.out.println("Parthesh is present in hash set ? " + hash.contains("Parthesh"));
		
		//remove any value from HashSet
		
		hash.remove("");
		hash.remove(null);
		
		System.out.println(hash);
		
		//define iterator of HashSet
		
				Iterator it = hash.iterator();
				
				while(it.hasNext())
				{
					System.out.println(it.next());
				}
	
		//Clear HashSet
		hash.clear();
		System.out.println("Values is hash is :" +hash);
		
		
	}

}
