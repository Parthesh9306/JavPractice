package collections;

import java.util.ArrayList;
import java.util.Iterator;

public class Iterator_in_ArrayList {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		ArrayList al=new ArrayList();
		
		for (int i=0;i<=5;i++)
		{
			al.add(i);
		}
		
		
		System.out.println(al);
		
		Iterator it= al.iterator();
		
		while(it.hasNext())
		{
			
			int i = (Integer) it.next();
			System.out.println(i);
			if(i%2==0)
			{
				it.remove();
			}
		}
		
		System.out.println(al);
		
		ArrayList<String> names=new ArrayList<String>();
		names.add("Parthesh");
		names.add("Abhinav");
		names.add("Ajeet");
		System.out.println(names);
		
		Iterator it1=names.iterator();
		
		while(it1.hasNext())
		{
			System.out.println(it1.next());
			
		}
	}

}
