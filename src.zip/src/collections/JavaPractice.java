package collections;

import java.util.ArrayList;

public class JavaPractice {

	
	public static void main(String[] args) {
		
		
		String abc = "parthesh is a good boy";
		
		char[] characters = abc.toCharArray();
		
		String uppercasesyntax =characters.toString().toUpperCase();
		
		
		/*for(int i=0;i<characters.length;i++)
		{
			//System.out.print(characters[i]);
			
			
			if(i==0)
			{
				
				char uppercasechar=Character.toUpperCase(characters[i]);
				System.out.print(uppercasechar);
			}
			else(Character.to)
			{
				
			}
			
		}*/
		//System.out.println(uppercasesyntax);
		
		
	}
}
