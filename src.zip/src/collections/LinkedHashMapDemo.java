package collections;
import java.util.*;

public class LinkedHashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		LinkedHashMap lmap = new LinkedHashMap();
		
		LinkedHashMap<String,Integer> lmap1 = new LinkedHashMap<String,Integer>();
		
		lmap1.put("Parthesh", 26);
		lmap1.put("Abhinav", 28);
		lmap1.put("Ajeet", 30);
		lmap1.put("Radhika", 25);
		lmap1.putIfAbsent("Parthesh", 26); // it will not print as it is already present
		lmap1.putIfAbsent("Parthesh", 27); // it will not print as it containd duplicate key ("Parthesh")
		
		System.out.println(lmap1);
		
		
	}

}
