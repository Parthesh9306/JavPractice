package collections;

import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		LinkedHashSet lhash = new LinkedHashSet();
		
		lhash.add(null);
		lhash.add("Abhinav");
		lhash.add("");
		lhash.add("Parthesh");
		lhash.add(25.684);
		lhash.add("Abhinav");
		lhash.add('G');
		
		System.out.println(lhash); //unlike HashSet, LinkedHashSet will maintain the insertion order
	}

}
