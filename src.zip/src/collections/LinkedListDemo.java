package collections;

import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList ll1 = new LinkedList();
		
		ll1.add(null);
		ll1.add(25);
		ll1.add("Parthesh");
		ll1.add("Abhinav");
		ll1.add('T');
		ll1.add("Ajeet");
		ll1.add(0.987);
		ll1.add("");
		ll1.add(null);
		
		System.out.println(ll1);
		
		// adding first element to the linked list
		ll1.addFirst("HDFC");
		
		// adding last element to the linked list
		ll1.addLast(256897.5584);
		
		System.out.println(ll1);
		
		
		LinkedList ll2 = new LinkedList();
		
		ll2.add("Parthesh");
		ll2.add("Ajeet");
		ll2.add("Abhinav");
		ll2.add("Krishna");
		ll2.add("Radhika");
		
		System.out.println("ll1 : " +ll2);
		
		ListIterator li = ll2.listIterator();
		
		while(li.hasNext())
		{
			String abc= (String) li.next();
			
			if(abc.equals("Abhinav"))
			{
				li.add("Pravin");
			}
			
		}
		System.out.println("Modified ll2 =" +ll2);
	}

	
	//rest all methods are same as list because linkedlist class implements methods of list interface
}
