package collections;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListIterator_in_ArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//ArrayList<Integer> al=new ArrayList<Integer>();
		ArrayList al=new ArrayList();

		for (int i=0;i<10;i++)
		{
			al.add(i);
		}
		System.out.println(al);
		System.out.println(al.get(3));
		//al.remove(2);
		//System.out.println(al);
		ListIterator li= al.listIterator();
		
		/*while(li.hasNext())
		{
			int j = (int) li.next();
		 if(j%2 == 0)
		 {
			 li.remove();
		 }
		}
		
		System.out.println(al);*/
		
		while(li.hasNext())
		{
			//System.out.println(li.next());
			
			int k = (int) li.next();
			
			if(k%2 == 0)
			{
				k++;
                li.set(k);
                li.add(k);
				
			}
		}
		System.out.println(al);
	}

}
