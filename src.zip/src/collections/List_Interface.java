package collections;

import java.util.ArrayList;
import java.util.List;

public class List_Interface {

	public static void main(String[] args) {
		
		
		List l1 = new ArrayList();
		
		for(int i=0; i<=10;i++)
		{
			l1.add(i);
		}
		System.out.println("List is created as : " + l1);
		
		//A) add new value at particular index in list
		
		l1.add(2,"Parthesh");
		l1.add(5, 'A');
		
		System.out.println("Modified List as : " + l1);
		
		List l2=new ArrayList();
		l2.add("Abhinav");
		l2.add("Ajeet");
		l2.add("Krishna");
		l2.add("Radhika");
		l2.add(null);
		l2.add("");
		l2.add(null);
		
		//B) add another collection in list
		l1.addAll(0,l2);
		
		System.out.println("Modified List after adding list l2 : " + l1);
		
		//C) Removing element from list

		l1.remove(8);
		
		System.out.println("Modified List after removing element : " + l1);
		
		//D) get object from particular index
		
		System.out.println("Element at 6th index is : " + l1.get(6));
		
		//E) Set/Update/Replace existing object with new object
		
		l1.set(10, 25.68);
		
		System.out.println("Modified List after replacing element : " + l1);
		
		
		//F) Search in list :
		     
		     l1.add(6, "Ajeet");
		
		     l1.add(13, "Ajeet");
		     
		     System.out.println("Modified List after adding duplicate values: " + l1);
		     
		     int first_occurence = l1.indexOf("Ajeet");
		     
		     System.out.println("First occurence of Ajeet is at " + first_occurence);
		     
		     int last_occurence = l1.lastIndexOf("Ajeet");
		     
		     System.out.println("Last occurence of Ajeet is at " + last_occurence);
		     
		 //G) Range view in List : get partial list in to other list
		     
		     List l3 = new ArrayList();
		     
		     l3 = l1.subList(5, 8);
		     System.out.println("Partial List is : " + l3);
		     
		     l3 = l1.subList(5, 18);// 18 is used to include last value
		     System.out.println("Another Partial List is : " + l3);
	}
}
