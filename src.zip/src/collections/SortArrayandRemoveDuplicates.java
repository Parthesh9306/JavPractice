package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

public class SortArrayandRemoveDuplicates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList alist = new ArrayList();
		alist.add(15);
		alist.add(12);
		alist.add(25);
		alist.add(10);
		alist.add(100);
		alist.add(12);
		
		// sort array
		Collections.sort(alist);
		System.out.println("Sorted array list :"+alist);
		
		// sort array and remove duplicates
		TreeSet tset = new TreeSet(alist);
		System.out.println("Sorted and Unique values :" +tset);
	}

}
