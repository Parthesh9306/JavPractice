package collections;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		
		TreeSet tset = new TreeSet();
		
		
		
		//TreeSet tsetcollection = new TreeSet();
		//tset.add(null); --> can not add null values in TreeSet. 
		tset.add(25);
		tset.add(698);
		tset.add(12);
		tset.add(40);
		//tset.add(null); --> can not add null values in TreeSet.
		tset.add(800);
		//tset.add(56.78); --> only same type of data is allowed
		tset.add(256);
		
		
		System.out.println(tset);
		
		TreeSet tsetstring = new TreeSet();
		
		
		tsetstring.add("Parthesh");
		tsetstring.add("Abhinav");
		tsetstring.add("polo");
		tsetstring.add("xmas");
		tsetstring.add("radhika");
		tsetstring.add("XMAS");
		tsetstring.add("Parthesh");// it will ignore this value as it is duplicate
		tsetstring.add("parthesh");
		tsetstring.add("$%^&#$");
		tsetstring.add("256");
		//tsetstring.add(12); --> only same type of values are allowed

		System.out.println(tsetstring);
		
		//addall method in treeset
		
		TreeSet tsetstring1 = new TreeSet();
		
		tsetstring1.addAll(tsetstring);
		
		tsetstring1.add("Pravin");
		tsetstring1.add("Kaushal");
		
		System.out.println("Appended TsetString1 is : " +tsetstring1);
		
		//object present or not
		System.out.println("parthesh present in TsetString or not : " +tsetstring.contains("parthesh"));
		
		//get first object of tsetstring
		System.out.println("First object present in tsetstring is : " +tsetstring.first());
		
		//get last object of tsetstring
        System.out.println("First object present in tsetstring is : " +tsetstring.last());
        
        //get less than the specified element
        System.out.println("Objects below 40 are : " +tset.headSet(40));
        
        //get less than the specified element - including specified element
         System.out.println("Objects below 40 are : " +tset.headSet(40,true)); // it will include '40'
         
        //get greater than the specified element
         System.out.println("Objects below 40 are : " +tset.tailSet(40));
         
        //get subset between specific values
         System.out.println("Objects between 25 and 256 are : " +tset.subSet(25, 750));
        
       //get subset between specific values - including to value
         System.out.println("Objects between 25 and 256 are : " +tset.subSet(25, false, 750, true));
	}

}
