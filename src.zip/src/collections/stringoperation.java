package collections;

public class stringoperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		System.out.println("Parthesh");
	}

}
