
public  class learningabstraction extends Abstract_Class {

	@Override
	public void non_concrete_method() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void non_concrete_method_2() {
		// TODO Auto-generated method stub
		
	}

	
		

		
		
		

	}

	
	
		
	


