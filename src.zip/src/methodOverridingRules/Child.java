package methodOverridingRules;

public class Child extends Parent{

	public static void print()
	{
		System.out.println("Print from Child");
	}
	
	public void add()
	{
		System.out.println("Add from Child");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Child c = new Child(); // Child c ==> Reference and new Child() ==> Object
		c.print(); // if both methods are static then object's class method will be created
		c.add(); // 
		
		
		Parent p = new Parent();
		p.print();
		p.add();
		
		
		Parent p1 = new Child(); // Reference is of Parent class and Object is from child class
		p1.print(); // print will be called from Parent as it is static and reference is of Parent
		p1.add(); // add will be called from child as add() is non-static
		
		c.substract();
		
		//Child c1= new Parent(); ==> this is not allowed (reference is of child and object is of parent)
	}

}
