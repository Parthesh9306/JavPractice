package methodOverridingRules;

public class Parent {

	
	public static void print()
	{
		System.out.println("Print from parent");
	}
	
	public void add()
	{
		System.out.println("Add from Parent");
	}
	
	void substract() //default access modifier (i.e it can not be called out side this package) 
	{
		System.out.println("substraction");
	}
	
	protected void multiplication() //default access modifier (i.e it can not be called out side this package) 
	{
		System.out.println("multiplication");
	}
}
