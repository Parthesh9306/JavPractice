import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class pattern {

	public static void main(String[] args) {
	
		String str= "Bangalore Abhinav pune Abhinav Bangalore";
		
		int count=0;
		int count1=0;
		int count2=0;
		
		String patternstring = "Abhinav";
		String patternstring1= "pune";
		String patternstring2= "Bangalore";
		
		Pattern pattern = Pattern.compile(patternstring,Pattern.CASE_INSENSITIVE);
		Pattern pattern1 = Pattern.compile(patternstring1,Pattern.CASE_INSENSITIVE);
		Pattern pattern2 = Pattern.compile(patternstring2,Pattern.CASE_INSENSITIVE);
		
		Matcher matcher = pattern.matcher(str);
		Matcher matcher1 = pattern1.matcher(str);
		Matcher matcher2 = pattern2.matcher(str);
		
		 while(matcher.find())
		 {
			 count++;
		 }
		 
		 while(matcher1.find())
		 {
			 count1++;
		 }
		 
		 while(matcher2.find())
		 {
			 count2++;
		 }
		 
		 System.out.println("Abhinav="+count);
		 System.out.println("pune="+count1);
		 System.out.println("Bangalore="+count2);

	}

}
