
public class runner {

	public static void main(String[] args) {
		
		Practice.JDBC_Connectivity("jdbc:oracle:thin:@192.168.168.61:1521/PRODUCT_QA", "SPPRODUCT5", "SPPRODUCT5" , "select * from minf where p_mid='IA43F52447942C19'", "P_MID", "P_MSG_TYPE");

	}

}
