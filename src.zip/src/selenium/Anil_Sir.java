package selenium;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Anil_Sir {

	public static void main(String[] args) {
		
		Calendar calendar = Calendar.getInstance();
		int weekday = calendar.get(Calendar.DAY_OF_WEEK);
		String d = new String("1");
        System.out.println(d); 
          int day = Integer.parseInt(d);
		int days = day - weekday;
		if (days < 0)
		{
		  
		    days += 7;
		} 
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date = calendar.getTime();
		calendar.add(Calendar.DAY_OF_YEAR, days);
		date = calendar.getTime();
		System.out.println("first day: "+sdf.format(date));
		
		String str = sdf.format(date);
		
		System.out.println("In a Variable: "+str);

	}

}
