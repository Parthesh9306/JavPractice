package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Parameters;

public class AssertText {

	WebDriver driver;
	
	@Parameters("Browsers")
	
	@org.testng.annotations.Test
	public void login(String browser) 
	{
		if(browser.equalsIgnoreCase("Chrome")) 
		{
		
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\All_Drivers\\chromedriver.exe");
		
		    driver = new ChromeDriver();
		
		    driver.get("http://www.google.com");
		
		    driver.manage().window().maximize();
		
		    driver.close();
		
		}
	}
	
	@org.testng.annotations.Test
	public void login1(String browser)
	{
		
		if(browser.equalsIgnoreCase("IE")) 
		
		{
		
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "\\All_Drivers\\IEDriverServer.exe");
		
			driver = new InternetExplorerDriver();
		
			driver.get("http://www.google.com");
		
		    driver.manage().window().maximize();
		
		    driver.close();
	}
	
	}
		
	}	

	
	

