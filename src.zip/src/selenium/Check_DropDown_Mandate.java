package selenium;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Check_DropDown_Mandate {

	
public static void main(String[] args) throws AWTException, InterruptedException {
	
	System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"\\All_Drivers\\IEDriverServer.exe");
	
	WebDriver driver = new InternetExplorerDriver();
	
	driver.get("http://splinux21.fundtech.isr:9502/gpp/#/user/signin");
	
	driver.manage().window().maximize();
	
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
	driver.manage().deleteAllCookies();
	
	driver.findElement(By.xpath("//input[@data-qa-id='omni-searchbox-locality']")).click();
	
	driver.findElement(By.xpath("//input[@data-qa-id='omni-searchbox-locality']")).clear();
	
	driver.findElement(By.xpath("//input[@data-qa-id='omni-searchbox-locality']")).sendKeys("Pune");
	
	driver.findElement(By.xpath("//div[@data-qa-id='omni-suggestion-main' and text()='Pune']")).click();
	
	driver.findElement(By.xpath("//input[@data-qa-id='omni-searchbox-keyword']")).click();
	
	driver.findElement(By.xpath("//input[@data-qa-id='omni-searchbox-keyword']")).sendKeys("Dentist");
	
	driver.findElement(By.xpath("//div[@data-qa-id='omni-suggestion-main' and text()='Dentist']")).click();
	
	List<WebElement> elem = driver.findElements(By.xpath("//span[contains(text(),'View Profile')]"));
	
	for(int i=0;i<elem.size();)
	{
		elem.get(i).click();
		
		break;
	}
	
	//Actions action = new Actions(driver);
	
	//action.contextClick();
	
	Robot r = new Robot();
	
	r.keyPress(KeyEvent.VK_CONTROL);
	r.keyPress(KeyEvent.VK_S);
	
	Thread.sleep(5000);
	
	r.keyPress(KeyEvent.VK_ALT);
	r.keyPress(KeyEvent.VK_T);
	
	Thread.sleep(2000);
	
	r.keyPress(KeyEvent.VK_DOWN);
	Thread.sleep(2000);
	r.keyPress(KeyEvent.VK_UP);
	Thread.sleep(2000);
	r.keyPress(KeyEvent.VK_ENTER);
	
	Thread.sleep(2000);

	r.keyPress(KeyEvent.VK_ENTER);
	
	
	
	
}
	

}
