package selenium;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;


public class DayfromBD {

	public static void main(String[] args) throws ParseException {
		
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");

		String date = "12/09/2018";
		
		//convert String to LocalDate
		LocalDate localDate = LocalDate.parse(date, formatter);
		
		System.out.println(localDate);
		
		 // Current day
	    DayOfWeek day1 = localDate.getDayOfWeek();
	    System.out.println("Today's day: "+day1);
	    
	    // Converting current day to String
	    String currentday = day1.toString();
	    
        if(currentday.equalsIgnoreCase("Friday"))
	    	
	    {
	    	LocalDate ud =  localDate.plusDays(1);
	    	System.out.println("Next date is: "+ud);
	    	
	    }
	    
	    else if(currentday.equalsIgnoreCase("Monday"))
	    {
	    	LocalDate ud =  localDate.plusDays(5);
	    	System.out.println("Next date is: "+ud);
	    }
	    
	    else if(currentday.equalsIgnoreCase("Tuesday"))
	    {
	    	LocalDate ud =  localDate.plusDays(4);
	    	System.out.println("Next date is: "+ud);
	    }
	    
	    else if(currentday.equalsIgnoreCase("Wednesday"))
	    {
	    	LocalDate ud =  localDate.plusDays(3);
	    	System.out.println("Next date is: "+ud);
	    }
	    
	    else if(currentday.equalsIgnoreCase("Thrusday"))
	    {
	    	LocalDate ud =  localDate.plusDays(2);
	    	System.out.println("Next date is: "+ud);
	    }
	    
	    else if(currentday.equalsIgnoreCase("Sunday"))
	    {
	    	LocalDate ud =  localDate.plusDays(6);
	    	System.out.println("Next date is: "+ud);
	    }
	    
	   
	}

	    
	      
	      
        
	}


