package selenium;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {

	private static FileInputStream fis;
	private static XSSFWorkbook wb;
	private static XSSFSheet sheet;
	
	 public static Object[][] getdata(String SheetName) 
	 {
		 try 
		 { 
			 fis = new FileInputStream("F://TestData.xlsx");
			 
			 wb = new XSSFWorkbook(fis);
			 
			 sheet = wb.getSheet(SheetName);
			 
			 int lastRowNum = sheet.getLastRowNum();
			 int lastColNum = sheet.getRow(1).getLastCellNum();
			 
			 Object[][] data = new Object[lastRowNum][lastColNum];
			 
			 for(int i=0;i<lastRowNum;i++) 
			 {
				 for(int j=0;j<lastColNum;j++) 
				 {
					 data[i][j] = sheet.getRow(i).getCell(j).toString(); 
				 }
			 }
			 
			 
			 return data;
		 } 
		 
		 catch (FileNotFoundException e) 
		 {
			e.printStackTrace();
		 } 
		 
		 catch (IOException e) 
		 {
			e.printStackTrace();
		
		 }
		return null;
		
		 
		 
	 }
	 
	 
	

	 
	 
}
	 

	 


