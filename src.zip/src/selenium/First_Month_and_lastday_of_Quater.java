package selenium;

import java.time.LocalDate;
import java.time.Month;




public class First_Month_and_lastday_of_Quater {

	public static void main(String[] args) {
		
		// Current date
	    LocalDate date = LocalDate.now();
	    System.out.println("Today's date: "+date);
	
		
	    //Current Month
	    Month month = date.getMonth();
	   	System.out.println("Month of the Date is: "+month);
		
		
	    //Conditions to Check Months
	   	
	   	if(date.getMonth().equals(Month.SEPTEMBER))
	   	{
	   	
	   		LocalDate futureDate = LocalDate.now().plusMonths(1);
	        System.out.println("Future Date is: "+futureDate);
	   
	        LocalDate lastdateofmonth = futureDate.withDayOfMonth(futureDate.lengthOfMonth());
	        System.out.println("Last Date of the Month is: "+lastdateofmonth);
	        
	        String lastbd = lastdateofmonth.toString();
	        
	        System.out.println(lastbd);
	   	}
	   	
	   	else if(date.getMonth().equals(Month.AUGUST))
	   	{
	   	
	   		LocalDate futureDate = LocalDate.now().plusMonths(2);
	        System.out.println("Future Date is: "+futureDate);
	   
	        LocalDate lastdateofmonth = futureDate.withDayOfMonth(futureDate.lengthOfMonth());
	        System.out.println("Last Date of the Month is: "+lastdateofmonth);
	   	}
	   	
	   	else if(date.getMonth().equals(Month.MAY))
	   	{
	   	
	   		LocalDate futureDate = LocalDate.now().plusMonths(2);
	        System.out.println("Future Date is: "+futureDate);
	   
	        LocalDate lastdateofmonth = futureDate.withDayOfMonth(futureDate.lengthOfMonth());
	        System.out.println("Last Date of the Month is: "+lastdateofmonth);
	   	}
	   	
	   	else if(date.getMonth().equals(Month.JUNE))
	   	{
	   	
	   		LocalDate futureDate = LocalDate.now().plusMonths(1);
	        System.out.println("Future Date is: "+futureDate);
	   
	        LocalDate lastdateofmonth = futureDate.withDayOfMonth(futureDate.lengthOfMonth());
	        System.out.println("Last Date of the Month is: "+lastdateofmonth);
	   	}
	   	
	   	else if(date.getMonth().equals(Month.FEBRUARY))
	   	{
	   	
	   		LocalDate futureDate = LocalDate.now().plusMonths(2);
	        System.out.println("Future Date is: "+futureDate);
	   
	        LocalDate lastdateofmonth = futureDate.withDayOfMonth(futureDate.lengthOfMonth());
	        System.out.println("Last Date of the Month is: "+lastdateofmonth);
	   	}
	   	
	   	else if(date.getMonth().equals(Month.MARCH))
	   	{
	   	
	   		LocalDate futureDate = LocalDate.now().plusMonths(1);
	        System.out.println("Future Date is: "+futureDate);
	   
	        LocalDate lastdateofmonth = futureDate.withDayOfMonth(futureDate.lengthOfMonth());
	        System.out.println("Last Date of the Month is: "+lastdateofmonth);
	   	}
	}

}
