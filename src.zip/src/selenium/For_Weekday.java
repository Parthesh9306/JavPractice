package selenium;

import java.time.DayOfWeek;
import java.time.LocalDate;

public class For_Weekday {

	public static void main(String[] args) {
		
		 // Current date
	    LocalDate date1 = LocalDate.now();
	    System.out.println("Today's date: "+date1);
	    
	    // Current day
	    DayOfWeek day1 = date1.getDayOfWeek();
	    System.out.println("Today's day: "+day1);
	    
	    // Converting current day to String
	    String currentday = day1.toString();
	    
	    if(currentday.equalsIgnoreCase("Friday"))
	    	
	    {
	    	LocalDate ud =  date1.plusDays(3);
	    	System.out.println("Next date is: "+ud);
	    	
	    }
	    
	    else if(currentday.equalsIgnoreCase("Sunday"))
	    {
	    	LocalDate ud =  date1.plusDays(1);
	    	System.out.println("Next date is: "+ud);
	    }
	    
	    else if(currentday.equalsIgnoreCase("Tuesday"))
	    {
	    	LocalDate ud =  date1.plusDays(6);
	    	System.out.println("Next date is: "+ud);
	    }
	    
	    else if(currentday.equalsIgnoreCase("Wednesday"))
	    {
	    	LocalDate ud =  date1.plusDays(5);
	    	System.out.println("Next date is: "+ud);
	    }
	    
	    else if(currentday.equalsIgnoreCase("Thrusday"))
	    {
	    	LocalDate ud =  date1.plusDays(4);
	    	System.out.println("Next date is: "+ud);
	    }
	    
	    else if(currentday.equalsIgnoreCase("Satuday"))
	    {
	    	LocalDate ud =  date1.plusDays(2);
	    	System.out.println("Next date is: "+ud);
	    }
	    
	   
	}



	}


