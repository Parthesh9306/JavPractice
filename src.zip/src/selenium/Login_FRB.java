package selenium;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Login_FRB {

	public static void main(String[] args) throws IOException, InterruptedException {
		
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+ "\\src\\selenium\\FRB.properties");
		
		Properties prop = new Properties();
		
		prop.load(fis);
		
        System.setProperty("webdriver.ie.driver", "C:\\Program Files\\SmartBear\\SoapUI-5.4.0\\bin\\ext\\IEDriverServer.exe");
		
		WebDriver driver = new InternetExplorerDriver();
		
		driver.get("http://splinux21.fundtech.isr:9312/gpp/");
		
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath(prop.getProperty("USERNAME_XPATH"))).sendKeys("AUTOMATI");
		
		driver.findElement(By.xpath(prop.getProperty("PASSWORD_XPATH"))).sendKeys("abc123");
		
		WebElement elem = driver.findElement(By.xpath(prop.getProperty("LOGIN_BUTTON_XPATH")));
		
		driver.manage().deleteAllCookies();
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		
		wait.until(ExpectedConditions.visibilityOf(elem));
		
		elem.click();
		
		//driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		Thread.sleep(15000);
		
		driver.findElement(By.xpath("(//span[contains(text(),'Business Setup')])[1]")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//div[contains(text(),'Parties')]")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//input[@id='CUSTOMRS-CUST_NAME']")).sendKeys("BANCO DI CARIBE N.V. BONAIRE");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//span[contains(text(),'Apply Filters')]")).click();
		
		WebElement elem1 = driver.findElement(By.xpath("(//div[@class='ui-grid-cell-contents ng-scope']/span)[5]"));
		
		System.out.println(elem1.getText());
		
		Assert.assertEquals(elem1.getText(), "BANCO DI CARIBE N.V. BONAIRE");
		
		DesiredCapabilities dc = new DesiredCapabilities();
		
		dc.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
		
	}

}
