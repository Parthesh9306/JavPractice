package selenium;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Pacs003_Cancel {

	public static void main(String[] args) throws InterruptedException {
		
        System.setProperty("webdriver.ie.driver", "C:\\Program Files\\SmartBear\\SoapUI-5.4.0\\bin\\ext\\IEDriverServer.exe");
		
		WebDriver driver = new InternetExplorerDriver();
		
		driver.get(args[0]);
		//driver.get("http://splinux11.fundtech.isr:13412/gpp");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.manage().window().maximize();
		
		
		driver.findElement(By.xpath("//input[@placeholder='User ID']")).sendKeys(args[1]);
		//driver.findElement(By.xpath("//input[@placeholder='User ID']")).sendKeys("ADI1");
		
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(args[2]);
		//driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("abc123");
		
		WebElement elem = driver.findElement(By.xpath("//span[contains(text(),'LOGIN')]"));
		
		driver.manage().deleteAllCookies();
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		
		wait.until(ExpectedConditions.visibilityOf(elem));
		
		elem.click();
		
		Thread.sleep(15000);
		
		
		// Id for Parent Window
		String parentwindow = driver.getWindowHandle();
		System.out.println("Parent Window : "+parentwindow);		
		//Operation on Parent Window
				
		driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys(args[3]);
		
		//driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("I09QA1603K700I2N");
		
		driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys(Keys.ENTER);
		
		driver.findElement(By.xpath("(//span[contains(text(),'"+args[3]+"')])[2]")).click();
		
		//driver.findElement(By.xpath("(//span[contains(text(),'I09QC3424A200I1M')])[2]")).click();
		
		Thread.sleep(10000);
		
		//Id for allwindows
		
		Set<String> allwindow = driver.getWindowHandles();
		
		System.out.println("All window: "+allwindow);
		
		// Iterate through all windows
		Iterator<String> itr = allwindow.iterator();
		
		while(itr.hasNext())
		{
			String childwin = itr.next();
			
			if(!parentwindow.equalsIgnoreCase(childwin))
			{
				driver.switchTo().window(childwin);
				
				Thread.sleep(8000);
				
				driver.findElement(By.xpath("//button[@name='Cancel Request']")).click();
			}
		}
		
		Thread.sleep(15000);
		
		Set<String> window2 = driver.getWindowHandles();
		
		System.out.println(window2);
		
		// Iterate through all windows
				Iterator<String> itr1 = window2.iterator();
				
				while(itr1.hasNext())
				{
					String childwin2 = itr1.next();
					
					if(!parentwindow.equalsIgnoreCase(childwin2))
					{
						driver.switchTo().window(childwin2);
						
						Thread.sleep(8000);
						
						driver.manage().window().maximize();
						
						Thread.sleep(8000);
						
						driver.findElement(By.xpath("//button[@name='Submit']")).click();
					}
				}
		
		
		
				
				
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
				driver.switchTo().window(parentwindow);
				
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				
		        driver.findElement(By.xpath("//span[contains(text(),'Sign Out')]")).click();
		        
		        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		        
		        driver.close();
		        
		
	}

	
}
