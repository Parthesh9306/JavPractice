package selenium;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Resend_Pacs002 {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.ie.driver", "C:\\Program Files\\SmartBear\\SoapUI-5.4.0\\bin\\ext\\IEDriverServer.exe");
        
        WebDriver driver = new InternetExplorerDriver();
        
        driver.get(args[0]);
        //driver.get("http://splinux11.fundtech.isr:13412/gpp");
        
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        
        driver.manage().window().maximize();
        
        
        driver.findElement(By.xpath("//input[@placeholder='User ID']")).sendKeys(args[1]);
        //driver.findElement(By.xpath("//input[@placeholder='User ID']")).sendKeys("ADI1");
        
        driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(args[2]);
        //driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("abc123");
        
        WebElement elem = driver.findElement(By.xpath("//span[contains(text(),'LOGIN')]"));
        
        driver.manage().deleteAllCookies();
        
        WebDriverWait wait = new WebDriverWait(driver,30);
        
        wait.until(ExpectedConditions.visibilityOf(elem));
        
        elem.click();
        
        Thread.sleep(15000);
        
        
        // Id for Parent Window
        String parentwindow = driver.getWindowHandle();
        System.out.println("Parent Window : "+parentwindow);          
        //Operation on Parent Window
                     
        driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys(args[3]);
        
        //driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("I09QA1603K700I2N");
        
        driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys(Keys.ENTER);
        
        driver.findElement(By.xpath("(//span[contains(text(),'"+args[3]+"')])[2]")).click();
        
        //driver.findElement(By.xpath("(//span[contains(text(),'I09QC3424A200I1M')])[2]")).click();
        
        Thread.sleep(10000);
        
        //Id for allwindows
        
        Set<String> allwindow = driver.getWindowHandles();
        
        System.out.println("All window: "+allwindow);
        
        // Iterate through all windows
        Iterator<String> itr = allwindow.iterator();
        
        while(itr.hasNext())
        {
               String childwin = itr.next();
               
               if(!parentwindow.equalsIgnoreCase(childwin))
               {
                     driver.switchTo().window(childwin);
                     
                     Thread.sleep(8000);
                     
                     driver.findElement(By.xpath("//button[@name='MessageExternalInteractions']")).click();
                     
                     Thread.sleep(8000);
                     
                     driver.findElement(By.xpath("//button[@name='Close']")).click();
                     
                    Thread.sleep(8000);
               }
        }
        
        Thread.sleep(10000);
        
        
        driver.switchTo().window(parentwindow);
        
        Thread.sleep(3000);
        
        driver.findElement(By.xpath("//span[text()='ACK']")).click();
        Thread.sleep(8000);
        Set<String> transactionwindows2 = driver.getWindowHandles();
        
        Iterator<String> itr1 = transactionwindows2.iterator();
        itr1.next();
        //String pacs002_win = itr1.next();
        Thread.sleep(5000);
        driver.switchTo().window(itr1.next());
        Thread.sleep(5000);
        //System.out.println("reached here");
        driver.manage().window().maximize();
        //System.out.println("reached here 1");
        //driver.findElement(By.id("MESSAGE_EXTERNAL_INTERACTION.ALLOW_RESEND")).getText();
        //System.out.println("reached here 2");
        //String Allow_Resend = driver.findElement(By.id("MESSAGE_EXTERNAL_INTERACTION.ALLOW_RESEND")).getText();
        
        String Allow_Resend = driver.findElement(By.id("MESSAGE_EXTERNAL_INTERACTION.ALLOW_RESEND")).getAttribute("value");
        
        System.out.println("Allow_Resend is : " + Allow_Resend);
        
        if(Allow_Resend.equalsIgnoreCase("YES"))
        {
              System.out.println("Allow Resend is YES as per expected");
        }
        else
        {
              System.out.println("Allow Resend is "+ Allow_Resend + " not as per expected");
        }
        
        driver.findElement(By.xpath("//button[text()='Resend']")).click();
        
        Thread.sleep(8000);
        
        driver.switchTo().window(parentwindow);
        
        driver.findElement(By.xpath("//span[text()='Sign Out']")).click();
        Thread.sleep(10000);
        
        driver.close();

       }



	}



