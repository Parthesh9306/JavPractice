package selenium;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Suspend_mandate {

	public static void main(String[] args) throws InterruptedException {
		
		//System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+ "\\All_Drivers\\IEDriverServer.exe");
	
		System.setProperty("webdriver.ie.driver", "C:\\Program Files\\SmartBear\\SoapUI-5.4.0\\bin\\ext\\IEDriverServer.exe");
		
		WebDriver driver = new InternetExplorerDriver();
		
		driver.get("http://splinux21.fundtech.isr:9502/gpp/#/user/signin");
		
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id='signin-username-field']")).sendKeys("ABHINAV1");
		
		driver.findElement(By.xpath("//input[@id='signin-password-field']")).sendKeys("abc321");
		
		WebElement elem = driver.findElement(By.xpath("//button[@id='signin-login-button']"));
		
		driver.manage().deleteAllCookies();
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		
		wait.until(ExpectedConditions.visibilityOf(elem));
		
		elem.click();
		
		Thread.sleep(15000);
		
		WebDriverWait wait1 = new WebDriverWait(driver,50);
		//wait1.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//button[@class='btn dh-navigation-button ng-isolate-scope'])[4]"))));
		
		wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),'Business Setup')])[1]")));
		
		driver.findElement(By.xpath("(//span[contains(text(),'Business Setup')])[1]")).click();
		
		Thread.sleep(8000);
		
		driver.findElement(By.xpath("(//i[@class='fa fa-th'])[3]")).click();
		
		driver.findElement(By.xpath("(//span[contains(text(),'Direct')])[2]")).click();
		
		driver.findElement(By.xpath("//span[contains(text(),'Mandates')]")).click();
		
		Thread.sleep(15000);
		
		driver.findElement(By.xpath("//span[contains(text(),'Refine')]")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("(//input[contains(@class,'ui-grid-filter-input ui-grid-filter-input-')])[7]")).sendKeys("201808280000000030");
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("(//input[contains(@class,'ui-grid-filter-input ui-grid-filter-input-')])[7]")).sendKeys(Keys.ENTER);
		
		Thread.sleep(10000);
		
		// Id for Parent Window
		String parentwindow = driver.getWindowHandle();
		
		//Operation on Parent Window
		driver.findElement(By.xpath("(//span[@class='ft-grid-click ng-binding'])[2]")).click();
		
		//Id for allwindows
		Set<String> allwindow = driver.getWindowHandles();
		
		// Iterate through all windows
		Iterator<String> itr = allwindow.iterator();
		
			
		
		while(itr.hasNext())
		{
			String childwin = itr.next();
			
			if(!parentwindow.equalsIgnoreCase(childwin))
			{
				driver.switchTo().window(childwin);
				
				Thread.sleep(8000);
				
				Select sel = new Select(driver.findElement(By.id("MANDATE.BUSINESS_STATUS")));
				
				sel.selectByVisibleText("Suspended");
				
				Thread.sleep(8000);
				
				driver.findElement(By.id("B_MANDATE.BUSINESS_STATUS_REASON_CD")).click();
				
				Thread.sleep(3000);
				
				driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src='../sd-html/ActionInputSearch.html']")));
				
				Thread.sleep(3000);
				
				//driver.findElement(By.xpath("(//div[@class='dhx_toolbar_btn def'])[1]/div")).click();
				
			
				String text = driver.findElement(By.xpath("//td[text()='CTAM']")).getText();
				String text1 = driver.findElement(By.xpath("//td[text()='CTCA']")).getText();
				String text2 = driver.findElement(By.xpath("//td[text()='CTEX']")).getText();
				String text3 = driver.findElement(By.xpath("//td[text()='MASC']")).getText();
				String text4 = driver.findElement(By.xpath("//td[text()='MCFC']")).getText();
				String text5 = driver.findElement(By.xpath("//td[text()='MCOC']")).getText();
				String text6 = driver.findElement(By.xpath("//td[text()='MSUC']")).getText();
				
				
				Assert.assertEquals(text, "CTAM");
				Assert.assertEquals(text1, "CTCA");
				Assert.assertEquals(text2, "CTEX");
				Assert.assertEquals(text3, "MASC");
				Assert.assertEquals(text4, "MCFC");
				Assert.assertEquals(text5, "MCOC");
				Assert.assertEquals(text6, "MSUC");
				
				Thread.sleep(5000);
				
				driver.findElement(By.xpath("(//div[@class='dhx_toolbar_btn def'])[2]/div")).click();
				
				driver.close();
				
				Thread.sleep(5000);
				
				//driver.switchTo().defaultContent();
				
				
				
			}
			
		}
		
		driver.switchTo().window(parentwindow);
		
		driver.findElement(By.id("navigation-logout-button")).click();
		
		Thread.sleep(10000);
		
		driver.close();
		
		
		
       
		
			
		}
		
	}


