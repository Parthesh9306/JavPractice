package selenium;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import com.sun.glass.events.KeyEvent;

public class Switch_Case_Example {

	public static void main(String[] args) throws IOException, AWTException {
		
		WebDriver driver = null;
		
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\selenium\\FRB.properties");
		
		Properties prop = new Properties();
		
		prop.load(fis);
		
		String browser = prop.getProperty("Browser");
		
		switch(browser)
		{
		    case "FireFox": 
		   
		    	driver = new FirefoxDriver();
		    	
		    case "InternetExplorer":
		    	System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+ "\\All_Drivers\\IEDriverServer.exe");
		        driver = new InternetExplorerDriver();
		        
		    case "Chrome":   
		
		    	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+ "\\All_Drivers\\chromedriver.exe");
		        driver = new ChromeDriver();
		        
		}
		
		driver.get("https://google.com");
		
		
	}

}
