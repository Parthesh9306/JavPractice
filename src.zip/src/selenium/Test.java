package selenium;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.util.SystemOutLogger;

public class Test {
	
public static void main(String[] args)  {
	
	String str = "parthesheheeh";
	
	char[] ch = str.toCharArray();
	
	Map<Character,Integer> hmap = new HashMap<Character,Integer>();
	
	for(char c:ch) 
	{
		if(hmap.containsKey(c)) 
		{
			hmap.put(c, hmap.get(c)+1);
		}
		
		else 
		{
			hmap.put(c, 1);
		}
	}
	
	int maxValueInMap= Collections.max(hmap.values());
	
	for(Map.Entry<Character,Integer> entry:hmap.entrySet()) {
		
		if (entry.getValue()==maxValueInMap) {
            System.out.println(entry.getKey() + " " +entry.getValue());     
        }
		
		
		
	}
	
	
	
	
	
	}
	
	
	
}
	
	
	
	
	
	


