package selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Test1 {

	public static void main(String[] args) {
		
        System.setProperty("webdriver.ie.driver", "C:\\Program Files\\SmartBear\\SoapUI-5.4.0\\bin\\ext\\IEDriverServer.exe");
		
		WebDriver driver = new InternetExplorerDriver();
		
		driver.get("http://splinux4.fundtech.isr:9582/gpp/");
		
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.manage().window().maximize();
		
		driver.findElement(By.id("txtUserId")).sendKeys("AUTO1");
		
		driver.findElement(By.id("txtPassword")).sendKeys("abc123");
		
		driver.findElement(By.id("SubmitForm")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		

	}

}
