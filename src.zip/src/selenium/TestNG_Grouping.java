package selenium;

import org.testng.annotations.Test;

public class TestNG_Grouping {
	
	@Test(groups={"car"})
	public void car1()
	{
		System.out.println("First method for car");
	}
	
	
	@Test(groups={"car"})
	public void car2()
	{
		System.out.println("Second car method");
	}
	
	@Test(groups={"scooter"})
	public void scooter1()
	{
		System.out.println("First method for scooter");
	}
	
	@Test(groups={"scooter"})
	public void scooter2()
	{
		System.out.println("Second method for scooter");
	}
	
	@Test(groups={"car","sedan car"})
	public void car_and_scooter()
	{
		System.out.println("Combination of Car and scooter method");
	}

}
