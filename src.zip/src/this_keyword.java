
public class this_keyword {

	int num;
	
	this_keyword(int num)
	{
		this.num=10;
	}
	
	public static void main(String[] args) {
		
		this_keyword t = new this_keyword(10);
		System.out.println(t.num);
	}
}
